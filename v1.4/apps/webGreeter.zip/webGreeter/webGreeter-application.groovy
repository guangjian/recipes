application {
	
	name="webGreeter"
	
	service {
		name = "webService"
	}
	
}
