This is for the ownCloud recipe with distributed DB and NFS server
It assumes image file with the necessary components already installed.