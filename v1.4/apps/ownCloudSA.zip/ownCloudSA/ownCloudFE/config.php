<?php
$CONFIG = array (
  'passwordsalt' => 'e790b05ab11a939244bc914a8cbc16',
  'datadirectory' => '/opt/ocStorage',
  'dbtype' => 'mysql',
  'version' => '4.90.3',
  'dbname' => 'owncloud',
  'dbhost' => 'MYSQLSERVERIP',
  'dbtableprefix' => 'oc_',
  'dbuser' => 'oc_admin',
  'dbpassword' => '35e3ba5788fd717cf53768d6f7a57288',
  'installed' => true,
  'instanceid' => '50b55842d09a4',
);